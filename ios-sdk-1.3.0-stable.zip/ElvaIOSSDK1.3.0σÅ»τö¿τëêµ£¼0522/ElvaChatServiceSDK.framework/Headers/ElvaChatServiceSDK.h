//
//  ElvaChatServiceSDK.h
//  ElvaChatServiceSDK
//
//  Created by wwj on 16/7/21.
//  Copyright © 2016年 wwj. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ElvaChatServiceSDK.
FOUNDATION_EXPORT double ElvaChatServiceSDKVersionNumber;

//! Project version string for ElvaChatServiceSDK.
FOUNDATION_EXPORT const unsigned char ElvaChatServiceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ElvaChatServiceSDK/PublicHeader.h>


